package sk.thenoen.coronatest.coronatest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoronaTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoronaTestApplication.class, args);
	}

}
