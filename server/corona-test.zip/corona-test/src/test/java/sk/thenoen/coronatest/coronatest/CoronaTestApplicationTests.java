package sk.thenoen.coronatest.coronatest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
